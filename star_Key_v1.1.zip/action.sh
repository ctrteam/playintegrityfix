MODPATH="${0%/*}"

# Setup
set +o standalone
unset ASH_STANDALONE

sh $MODPATH/PLAT_L/kill_google_process.sh
sh $MODPATH/PLAT_L/star_keybox.sh
sh $MODPATH/PLAT_L/target_txt.sh
sh $MODPATH/PLAT_L/security_patch.sh

echo -e "$(date +%Y-%m-%d\ %H:%M:%S) Congratulations your device has strong integrity with STARDEV key ⭐💫🔥"

sh $MODPATH/PLAT_L/author.sh
sleep 1
echo " "
echo " "
echo "   - ⭐ THERE IS NO SYSTEM PERFECT ⭐ -   "
echo " "                                                                            
echo "   @@@@@@@@    @@@@@@  @@@    -*#@@##- @@@@@@        @@   "               
echo "  *@ *@@@ @@   @@% @@@ @@@    . @@@@-    @@          @@   "               
echo "  *@ @. @ @@   @@@@@@* @@@@    @@  @@    @@          @@@   "              
echo "  *@ *#:-=@   .@@%     @@@@@@ @@+@@%@@   @@.  @@@@@  @@@@@@   "           
echo "   *@@@@@                                      "                                                                                                 
echo " "
echo " "
echo "- ☎️ Telegram : @nerimo_ingPandum "
echo " "
echo "   DONE ✅ ✅ ✅      "
echo " "
echo " "
echo " "
sleep_pause
