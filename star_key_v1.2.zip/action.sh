MODPATH="${0%/*}"

# Setup
set +o standalone
unset ASH_STANDALONE

for SCRIPT in \
  "kill_google_process.sh" \
  "star_keybox.sh" \
  "target_txt.sh" \
  "security_patch.sh" \
  "boot_hash.sh"
do
  if ! sh "$MODPATH/PLAT_L/$SCRIPT"; then
    echo "- Error: $SCRIPT failed. Aborting."
    exit 1
  fi
done

if [ -f /data/adb/modules_update/starkey/webroot/common/device-info.sh ]; then
  sh /data/adb/modules_update/starkey/webroot/common/device-info.sh
elif [ -f /data/adb/modules/starkey/webroot/common/device-info.sh ]; then
  sh /data/adb/modules/starkey/webroot/common/device-info.sh
fi

echo -e "$(date +%Y-%m-%d\ %H:%M:%S) Congratulations your device has strong integrity with STARDEV key ⭐💫🔥"

sh $MODPATH/PLAT_L/author.sh
sleep 1
echo " "
echo " "
echo "   - ⭐ THERE IS NO SYSTEM PERFECT ⭐ -   "
echo " "                                                                            
echo "   @@@@@@@@    @@@@@@  @@@    -*#@@##- @@@@@@        @@   "               
echo "  *@ *@@@ @@   @@% @@@ @@@    . @@@@-    @@          @@   "               
echo "  *@ @. @ @@   @@@@@@* @@@@    @@  @@    @@          @@@   "              
echo "  *@ *#:-=@   .@@%     @@@@@@ @@+@@%@@   @@.  @@@@@  @@@@@@   "           
echo "   *@@@@@                                      "                                                                                                 
echo " "
echo " "
echo "- ☎️ Telegram : @nerimo_ingPandum "
echo " "
echo "  DONE     ✅ ✅ ✅      "
echo " "
echo " "
echo " "
sleep_pause

