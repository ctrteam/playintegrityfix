#!/bin/sh

log_message() {
    echo "$(date +%Y-%m-%d\ %H:%M:%S) [KILL_ALL] $1"
}

# Start
log_message "Start"

t='/data/adb/tricky_store/target.txt'

# Writing
log_message "Writing"

# add list special
fixed_targets="\
android
com.android.vending!
com.google.android.gms!
com.reveny.nativecheck!
io.github.vvb2060.keyattestation!
io.github.vvb2060.mahoshojo
icu.nullptr.nativetest
com.pubg.newstate
com.rekoo.pubgm
com.tencent.ig
com.pubg.krmobile
com.vng.pubgmobile
com.cibeg.ddc1.digitalbanking.live
com.google.android.gsf!
com.shopee.foody.driver.id
com.shopee.id
com.shopeepay.id
com.grabtaxi.driver2
com.grabtaxi.passenger
com.grab.merchant
com.gojek.partner
com.gojek.app
com.gojek.gopay
sinet.startup.inDriver
com.octopuscards.nfc_reader
ovo.id
id.co.bri.brimo
com.bca
id.bmri.livin
app.bpjs.mobile
com.bpjstku
com.finaccel.android
com.apps.MyXL
com.godevelopers.OprekCek
com.kai.kaiticketing
com.bukalapak.android
rikka.safetynetchecker
com.byxiaorun.detector
com.whatsapp!
com.whatsapp.w4b!
com.zhenxi.hunter
csii.com.qny
com.tencent.tmgp.sgame
com.tencent.mobileqq
com.dragon.read
com.tencent.tmgp.pubgmhd
com.tencent.mm
io.github.huskydg.memorydetector
com.android.updater
com.android.adservices.api
com.crgt.ilife
com.miui.securitymanager
com.lbe.security.miui
com.miui.systemAdSolution
com.miui.personalassistant
com.huawei.linkhome.assistant
com.netflix.mediaclient
com.henrikherzig.playintegritychecker
air.com.kotaksecurities.mobile
com.reveny.nativecheck
com.sankuai.meituan.meituanwaimaibusiness
com.fantasytat.propdor
com.xunmeng.pinduoduo
icu.nullptr.nativetest
com.zhenxi.hunter
com.msf.kbank.mobile"
for entry in $fixed_targets; do
    if ! echo "$entry" >> "$t"; then
        log_message "ERROR: Failed to write $entry to $t"
        exit 1
    fi
done

log_message "Finish"