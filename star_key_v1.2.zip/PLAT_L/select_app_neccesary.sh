#!/system/bin/sh

log_message() {
    echo "$(date +%Y-%m-%d\ %H:%M:%S) [KILL_ALL] $1"
}

# Start
log_message "Start"

t='/data/adb/tricky_store/target.txt'

# Writing
log_message "Writing"

# add list special
echo "android" > "$t"
echo "com.android.vending!" >> "$t"
echo "com.google.android.gsf!" >> "$t"
echo "com.google.android.gms!" >> "$t"
echo "io.github.vvb2060.keyattestation!" >> "$t"
echo "io.github.vvb2060.mahoshojo!" >> "$t"
echo "com.google.android.contactkeys!" >> "$t"
echo "com.google.android.ims!" >> "$t"
echo "com.google.android.safetycore!" >> "$t"
echo "com.google.android.apps.walletnfcrel!" >> "$t"
echo "com.google.android.apps.nbu.paisa.user!" >> "$t"
echo "gr.nikolasspyr.integritycheck!" >> "$t"
echo "com.youhu.laifu!" >> "$t"
echo "com.whatsapp!" >> "$t"
echo "com.whatsapp.w4b!" >> "$t"
echo "com.openai.chatgpt!" >> "$t"
echo "com.reveny.nativecheck!" >> "$t"
echo "icu.nullptr.nativetest!" >> "$t"
echo "com.android.nativetest!" >> "$t"
echo "io.liankong.riskdetector!" >> "$t"
echo "me.garfieldhan.holmes!" >> "$t"
echo "luna.safe.luna!" >> "$t"
echo "com.zhenxi.hunter!" >> "$t"

log_message "Finish"