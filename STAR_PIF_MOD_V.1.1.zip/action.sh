MODPATH="${0%/*}"

# ensure not running in busybox ash standalone shell
set +o standalone
unset ASH_STANDALONE

sh $MODPATH/PLAT_L/set_target.sh
sh $MODPATH/PLAT_L/set_security_patch.sh
sh $MODPATH/PLAT_L/install_keybox.sh
sh $MODPATH/PLAT_L/kill_gms_process.sh
sh $MODPATH/autopif2.sh -a -m -p || exit 1

echo -e "$(date +%Y-%m-%d\ %H:%M:%S) Closing dialog in 20 seconds.."
echo -e "$(date +%Y-%m-%d\ %H:%M:%S) Congratulations your device has strong integrity with STARDEV key ⭐💫🔥"
echo -e "$(date +%Y-%m-%d\ %H:%M:%S) Are you not pass strong integrity? try changing the spoof settings (without reboot) in /data/adb/modules/playintegrityfix/custom.pif.json"
echo -e "$(date +%Y-%m-%d\ %H:%M:%S) True = 1, False = 0"
echo -e "$(date +%Y-%m-%d\ %H:%M:%S) 1) Spoof Build: True, Spoof Props: True, Spoof Provider: True, Spoof Signature: False, Spoof Vending Sdk: False."
echo -e "$(date +%Y-%m-%d\ %H:%M:%S) 2) Spoof Build: True, Spoof Props: True, Spoof Provider: True, Spoof Signature: True, Spoof Vending Sdk: False."
echo -e "$(date +%Y-%m-%d\ %H:%M:%S) 3) Spoof Build: True, Spoof Props: True, Spoof Provider: True, Spoof Signature: True, Spoof Vending Sdk: True."
echo -e "$(date +%Y-%m-%d\ %H:%M:%S) 4) Spoof Build: False, Spoof Props: False, Spoof Provider: False, Spoof Signature: False, Spoof Vending Sdk: False."

echo
echo
echo "   - ⭐ THERE IS NO SYSTEM PERFECT ⭐ -   "
echo " "                                                                            
echo "   @@@@@@@@    @@@@@@  @@@    -*#@@##- @@@@@@        @@   "               
echo "  *@ *@@@ @@   @@% @@@ @@@    . @@@@-    @@          @@   "               
echo "  *@ @. @ @@   @@@@@@* @@@@    @@  @@    @@          @@@   "              
echo "  *@ *#:-=@   .@@%     @@@@@@ @@+@@%@@   @@.  @@@@@  @@@@@@   "           
echo "   *@@@@@                                      "                                                                                                 
echo " "
echo " "
echo " "
echo "- ☎️ Telegram : @nerimo_ingPandum "
echo " "
sleep 1
sh $MODPATH/PLAT_L/redirect.sh
echo
echo
echo "    DONE ✅ ✅ ✅      "
echo " "
echo " "
echo " "
echo " "
echo " "
sleep_pause