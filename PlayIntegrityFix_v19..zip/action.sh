echo "
             PLAT_L
╗────────────────────────────────────────╔
      @nerimo_ingPandum
      @Plat_L
      ───────────────────╚
"
sleep 2
echo   " ✅ Automatic update from Art of Rooting ✅"
ping -w 1 google.com &>/dev/null
if [ $? -ne 0 ]; then
    echo " SELAMAT DATANG DI CTR TEAM DEV "
    sleep 2
    exit 1
fi

# Download Strong File By @PlatL "
        curl -o /data/adb/tricky_store/keybox.xml https://raw.githubusercontent.com/ctrteam/playintegrityfix/refs/heads/main/key.xml
        curl -o /data/adb/pif.json https://raw.githubusercontent.com/ctrteam/playintegrityfix/refs/heads/main/pif.json
        curl -o /data/adb/tricky_store/target.txt https://raw.githubusercontent.com/ctrteam/playintegrityfix/refs/heads/main/target.txt
echo
echo
echo
echo " THERE IS NO SYSTEM PERFECT "
sleep 4
echo "▬▬▬.◙.▬▬▬"
echo "═▂▄▄▓▄▄▂"
echo "◢◤ █▀▀████▄▄▄▄◢◤"
echo "█▄ █ █▄ ███▀▀▀▀▀▀▀╬"
echo "◥█████◤"
echo "══╩══╩═"
echo "╬═╬"
echo "╬═╬"
echo "╬═╬"
echo "╬═╬"
echo "╬═╬☻/ Finishing installation"
echo "╬═╬/▌ ✅ UPDATE ✅🆙 DONE "
echo "╬═╬/ \ "
echo " "
sleep 1
nohup am start -a android.intent.action.VIEW -d https://t.me/nerimo_ingPandum >/dev/null 2>&1 &
echo
echo
echo "            PLAT_L "
echo
echo  
sleep_pause