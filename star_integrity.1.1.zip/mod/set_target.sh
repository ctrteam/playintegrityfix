#!/bin/sh

log_message() {
    echo "$(date +%Y-%m-%d\ %H:%M:%S) [SET_TARGET] $1"
}
log_message "start setting targets....."
t='/data/adb/tricky_store/target.txt'
tees='/data/adb/tricky_store/tee_status'

# tee status 
teeBroken="false"
if [ -f "$tees" ]; then
    teeBroken=$(grep -E '^teeBroken=' "$tees" | cut -d '=' -f2 2>/dev/null || echo "false")
fi

# add list special
echo "android" >> "$t"
echo "com.android.vending!" >> "$t"
echo "com.google.android.gms!" >> "$t"
echo "com.reveny.nativecheck!" >> "$t"
echo "io.github.vvb2060.keyattestation!" >> "$t"
echo "io.github.vvb2060.mahoshojo" >> "$t"
echo "icu.nullptr.nativetest" >> "$t"
echo "com.pubg.newstate" >> "$t"
echo "com.rekoo.pubgm" >> "$t"
echo "com.tencent.ig" >> "$t"
echo "com.pubg.krmobile" >> "$t"
echo "com.vng.pubgmobile" >> "$t"
echo "com.cibeg.ddc1.digitalbanking.live" >> "$t"
echo "com.google.android.gsf!" >> "$t"
echo "com.shopee.foody.driver.id" >> "$t"
echo "com.shopee.id" >> "$t"
echo "com.shopeepay.id" >> "$t"
echo "com.grabtaxi.driver2" >> "$t"
echo "con.grabtaxi.passenger" >> "$t"
echo "com.grab.merchant" >> "$t"
echo "com.gojek.partner" >> "$t"
echo "com.gojek.app" >> "$t"
echo "com.gojek.gopay" >> "$t"
echo "sinet.startup.inDriver" >> "$t"
echo "com.octopuscards.nfc_reader" >> "$t"
echo "ovo.id" >> "$t"
echo "id.co.bri.brimo" >> "$t"
echo "com.bca" >> "$t"
echo "id.bmri.livin" >> "$t"
echo "app.bpjs.mobile" >> "$t"
echo "com.bpjstku" >> "$t"
echo "com.finaccel.android" >> "$t"
echo "com.apps.MyXL" >> "$t"
echo "com.godevelopers.OprekCek" >> "$t"
echo "com.kai.kaiticketing" >> "$t"
echo "com.bukalapak.android" >> "$t"
echo "rikka.safetynetchecker" >> "$t"
echo "com.byxiaorun.detector" >> "$t"
echo "com.whatsapp!" >> "$t"
echo "com.whatsapp.w4b!" >> "$t"
echo "com.zhenxi.hunter" >> "$t"
echo "csii.com.qny" >> "$t"
echo "com.tencent.tmgp.sgame" >> "$t"
echo "com.tencent.mobileqq" >> "$t"
echo "com.dragon.read" >> "$t"
echo "com.tencent.tmgp.pubgmhd" >> "$t"
echo "com.tencent.mm" >> "$t"
echo "io.github.huskydg.memorydetector" >> "$t"
echo "com.android.updater" >> "$t"
echo "com.android.adservices.api" >> "$t"
echo "com.crgt.ilife" >> "$t"
echo "com.miui.securitymanager" >> "$t"
echo "com.lbe.security.miui" >> "$t"
echo "com.miui.systemAdSolution" >> "$t"
echo "com.miui.personalassistant" >> "$t"
echo "com.huawei.linkhome.assistant" >> "$t"
echo "com.netflix.mediaclient" >> "$t"
echo "com.henrikherzig.playintegritychecker" >> "$t"
echo "air.com.kotaksecurities.mobile" >> "$t"
echo "com.reveny.nativecheck" >> "$t"
echo "com.sankuai.meituan.meituanwaimaibusiness" >> "$t"
echo "com.fantasytat.propdor" >> "$t"
echo "com.xunmeng.pinduoduo" >> "$t"
echo "icu.nullptr.nativetest" >> "$t"
echo "com.zhenxi.hunter" >> "$t"
echo "com.msf.kbank.mobile" >> "$t"

# add list
add_packages() {
    pm list packages "$1" | cut -d ":" -f 2 | while read -r pkg; do
        if [ -n "$pkg" ] && ! grep -q "^$pkg" "$t"; then
            if [ "$teeBroken" = "true" ]; then
                echo "$pkg!" >> "$t"
            else
                echo "$pkg" >> "$t"
            fi
        fi
    done
}
log_message "Writing target..."

# add user apps
add_packages "-3"

# add system apps
add_packages "-s"
log_message "finished setting the target."