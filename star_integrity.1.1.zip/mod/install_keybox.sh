#!/system/bin/sh

MODPATH=/data/adb/modules/playintegrityfix 
KEYBOX_DIR="/data/adb/tricky_store"
KEYBOX_FILE="$KEYBOX_DIR/keybox.xml"
KEYBOX_BACKUP_FILE="$KEYBOX_DIR/keybox_backup.xml"
KEYBOX_URL="https://raw.githubusercontent.com/ctrteam/playintegrityfix/raw/refs/heads/main/key.xml"

log_message() {
    echo "$(date +%Y-%m-%d\ %H:%M:%S) [KEYBOX] $1"
}

if [ -f "$KEYBOX_FILE" ]; then
    log_message "Keybox.xml already available, back it up to keybox_backup.xml"
    mv "$KEYBOX_FILE" "$KEYBOX_BACKUP_FILE"
    if [ $? -eq 0 ]; then
        log_message "Backup Done."
    else
        log_message "Failedl membackup keybox.xml. Aborting."
        #exit 1
    fi
fi

log_message "processing keybox...."
# Menggunakan curl jika tersedia, jika tidak wget
if command -v curl >/dev/null 2>&1; then
    curl -sL "$KEYBOX_URL" -o "$KEYBOX_FILE"
elif command -v wget >/dev/null 2>&1; then
    wget -qO "$KEYBOX_FILE" "$KEYBOX_URL"
else
    log_message "Error: curl or wget not found. Unable to process keybox."
    #exit 1
fi

if [ $? -eq 0 ] && [ -f "$KEYBOX_FILE" ] && [ -s "$KEYBOX_FILE" ]; then
    log_message "Keybox processed successfully."
    chmod 0644 "$KEYBOX_FILE"
    log_message "Keybox permissions are set to 0644."
else
    log_message "Error: failed to verify keybox."
    #exit 1
fi
